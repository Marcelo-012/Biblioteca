
package interfaz;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import panel.CambiaPanel;
import panel.uno;
import panel.dos;
import panel.tres;


public class Inicio extends javax.swing.JFrame {

 
   
    public Inicio() {
        initComponents();
        this.setLocationRelativeTo(this);
        this.uno.setSelected(true);
        this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        new CambiaPanel (principal, new uno());
    }
    
     
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        menu = new javax.swing.JPanel();
        tres = new javax.swing.JButton();
        dos = new javax.swing.JButton();
        uno = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        principal = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        menu.setBackground(new java.awt.Color(150, 75, 0));
        menu.setLayout(new java.awt.GridBagLayout());

        tres.setBackground(new java.awt.Color(150, 75, 0));
        tres.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tres.setForeground(new java.awt.Color(204, 204, 204));
        tres.setText("LIBROS");
        tres.setBorder(null);
        tres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tresMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tresMouseExited(evt);
            }
        });
        tres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tresActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 104;
        gridBagConstraints.ipady = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 0, 0, 0);
        menu.add(tres, gridBagConstraints);

        dos.setBackground(new java.awt.Color(150, 75, 0));
        dos.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        dos.setForeground(new java.awt.Color(204, 204, 204));
        dos.setText("REGISTRO");
        dos.setBorder(null);
        dos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                dosMouseExited(evt);
            }
        });
        dos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dosActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 77;
        gridBagConstraints.ipady = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(22, 0, 0, 0);
        menu.add(dos, gridBagConstraints);

        uno.setBackground(new java.awt.Color(150, 75, 0));
        uno.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        uno.setForeground(new java.awt.Color(204, 204, 204));
        uno.setText("PRINCIPAL");
        uno.setBorder(null);
        uno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                unoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                unoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                unoMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                unoMousePressed(evt);
            }
        });
        uno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 71;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(145, 0, 0, 0);
        menu.add(uno, gridBagConstraints);

        exit.setBackground(new java.awt.Color(204, 0, 0));
        exit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exit.setForeground(new java.awt.Color(255, 255, 255));
        exit.setText("SALIR");
        exit.setBorder(null);
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 117;
        gridBagConstraints.ipady = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.insets = new java.awt.Insets(80, 1, 146, 0);
        menu.add(exit, gridBagConstraints);

        principal.setBackground(new java.awt.Color(204, 204, 204));
        principal.setLayout(new javax.swing.BoxLayout(principal, javax.swing.BoxLayout.LINE_AXIS));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(menu, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(principal, javax.swing.GroupLayout.DEFAULT_SIZE, 820, Short.MAX_VALUE)
                .addGap(2, 2, 2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
            .addComponent(principal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tresActionPerformed

        new CambiaPanel(principal, new tres());

        
    }//GEN-LAST:event_tresActionPerformed

    private void unoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unoActionPerformed
       

        new CambiaPanel(principal, new uno());
       
    }//GEN-LAST:event_unoActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
int i = JOptionPane.showConfirmDialog(null,"¿Seguro que quieres salir?");
        if (i==0){
            System.exit(0);
        }
    }//GEN-LAST:event_exitActionPerformed

    private void dosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dosActionPerformed

                new CambiaPanel(principal, new dos());

    }//GEN-LAST:event_dosActionPerformed

    private void unoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_unoMouseClicked

                         
    }//GEN-LAST:event_unoMouseClicked

    private void unoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_unoMouseEntered

        uno.setBackground(new Color(190,73,0));
        
    }//GEN-LAST:event_unoMouseEntered

    private void unoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_unoMouseExited

                uno.setBackground(new Color(150,75,0));

    }//GEN-LAST:event_unoMouseExited

    private void dosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dosMouseEntered

        dos.setBackground(new Color(190,73,0));

    }//GEN-LAST:event_dosMouseEntered

    private void dosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dosMouseExited

        dos.setBackground(new Color(150,75,0));

    }//GEN-LAST:event_dosMouseExited

    private void tresMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tresMouseEntered

        tres.setBackground(new Color(190,73,0));

    }//GEN-LAST:event_tresMouseEntered

    private void tresMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tresMouseExited

        tres.setBackground(new Color(150,75,0));
        
    }//GEN-LAST:event_tresMouseExited

    private void unoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_unoMousePressed


    }//GEN-LAST:event_unoMousePressed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dos;
    private javax.swing.JButton exit;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel principal;
    private javax.swing.JButton tres;
    private javax.swing.JButton uno;
    // End of variables declaration//GEN-END:variables
}
