/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Java_MySQL;
import java.sql.*;


/**
 *
 * @author dead2
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private final String url = "jdbc:mysql://127.0.0.1:3306/biblioteca"; 
    private final String user = "root"; 
    private final String password = "Marcelo029*";
    private Connection conectar = null;

    public Connection con() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            conectar = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
        } catch (SQLException e) {
        }
        return conectar;
    }
}
