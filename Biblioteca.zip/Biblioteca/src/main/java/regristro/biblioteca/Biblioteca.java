
package regristro.biblioteca;
import interfaz.Inicio;


public class Biblioteca {

    public static void main(String[] args) {
        Inicio p1 = new Inicio();
        p1.setVisible(true);


    }
}
