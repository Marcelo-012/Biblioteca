package panel;

import Java_MySQL.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;



public final class tres extends javax.swing.JPanel {


    public tres() {
        initComponents();
        actualizarTabla();
    }
    public void actualizarTabla() {
    DefaultTableModel modelo = MostrarLibros();
    TablaLibros.setModel(modelo);
    addCheckBox(5,TablaLibros);         
        
    DefaultTableCellRenderer centro = new DefaultTableCellRenderer(); 
    centro.setHorizontalAlignment(SwingConstants.CENTER);
    
    
    
        for (int i = 0; i < (TablaLibros.getColumnCount()-1); i++) {
            TablaLibros.getColumnModel().getColumn(i).setCellRenderer(centro);
        }
        
        TableColumnModel  TC = TablaLibros.getColumnModel();
        TC.getColumn(0).setPreferredWidth(50);
        TC.getColumn(1).setPreferredWidth(300);
        TC.getColumn(2).setPreferredWidth(300);
        TC.getColumn(3).setPreferredWidth(80);
        TC.getColumn(4).setPreferredWidth(80);
        TC.getColumn(5).setPreferredWidth(70);

}
  
      

public DefaultTableModel  MostrarLibros()   {
         
        String [] NC = {"#", "TUTULO", "AUTOR", "GENERO", "AÑO", "SELECT"};
        String [] registros = new String [5];
        
                
        DefaultTableModel m = new DefaultTableModel(null, NC)
        {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }};       
    

        
        String select = "SELECT * FROM libros";
        
        Conexion mysql = new Conexion();
        
        PreparedStatement pst = null;
        
        ResultSet rs = null;
        
        Connection cn =  mysql.con();        
         
        try{
             
             pst = cn.prepareStatement(select);
             
             rs = pst.executeQuery();
             
                while(rs.next()) {
                    registros[0] = rs.getString ("id");
                    registros[1] = rs.getString ("titulo");
                    registros[2] = rs.getString ("autor");
                    registros[3] = rs.getString ("genero");
                    registros[4] = rs.getString ("año");
                    
                    
                    m.addRow(registros);
         
                }
            
        }catch(SQLException e){
            
            JOptionPane.showMessageDialog(null,"Error al conectar");
        }
        finally
        {
            try{
                if (rs != null ) rs.close();
                if (pst != null )pst.close();
                if (cn != null ) cn.close();
            }
            catch(SQLException e){
            
                JOptionPane.showMessageDialog(null, e);

                    }
        }
        
         
            return m;
        
    }

public DefaultTableModel  BuscarLibros(String Search)   {
         
        String [] NC = {"#", "TUTULO", "AUTOR", "GENERO", "AÑO", "SELECT"};
        String [] registros = new String [5];
        
                
        DefaultTableModel m = new DefaultTableModel(null, NC)
        {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }};       
    

        
        String select = "SELECT * FROM libros WHERE genero LIKE '%"+Search+"%' OR titulo LIKE '%"+Search+"%' OR autor LIKE '%"+Search+"%' ";
        
        Conexion mysql = new Conexion();
        
        PreparedStatement pst = null;
        
        ResultSet rs = null;
        
        Connection cn =  mysql.con();        
         
        try{
             
             pst = cn.prepareStatement(select);
             
             rs = pst.executeQuery();
             
                while(rs.next()) {
                    registros[0] = rs.getString ("id");
                    registros[1] = rs.getString ("titulo");
                    registros[2] = rs.getString ("autor");
                    registros[3] = rs.getString ("genero");
                    
                    String FC = rs.getString ("año");
                    if (FC != null && FC.length()>=4) {
                        registros[4] = FC.substring(0, 4);
                    }
                    
                    m.addRow(registros);
         
                }
            
        }catch(SQLException e){
            
            JOptionPane.showMessageDialog(null,"Error al conectar");
        }
        finally
        {
            try{
                if (rs != null ) rs.close();
                if (pst != null )pst.close();
                if (cn != null ) cn.close();
            }
            catch(SQLException e){
            
                JOptionPane.showMessageDialog(null, e);

                    }
        }
        
         
            return m;
        
    }

public void BuscarLibroTabla(String Search) {
    DefaultTableModel modelo = BuscarLibros(Search);
    TablaLibros.setModel(modelo);
    addCheckBox(5,TablaLibros);         
        
    DefaultTableCellRenderer centro = new DefaultTableCellRenderer(); 
    centro.setHorizontalAlignment(SwingConstants.CENTER);
    
    
    
        for (int i = 0; i < (TablaLibros.getColumnCount()-1); i++) {
            TablaLibros.getColumnModel().getColumn(i).setCellRenderer(centro);
        }
        
        TableColumnModel  TC = TablaLibros.getColumnModel();
        TC.getColumn(0).setPreferredWidth(50);
        TC.getColumn(1).setPreferredWidth(300);
        TC.getColumn(2).setPreferredWidth(300);
        TC.getColumn(3).setPreferredWidth(80);
        TC.getColumn(4).setPreferredWidth(80);
        TC.getColumn(5).setPreferredWidth(70);

}    

public void addCheckBox(int column, JTable table){
   
    TableColumn tc = table.getColumnModel().getColumn(column);
    tc.setCellEditor(table.getDefaultEditor(Boolean.class));
    tc.setCellRenderer(table.getDefaultRenderer(Boolean.class));
        
}

public boolean Seleccionar(int row, int column, JTable table){
   
    return table.getValueAt(row, column) != null;

}

public boolean eliminar(int id){
    String C = "DELETE FROM libros WHERE id = ?";
    
    PreparedStatement pst;
    Conexion mysql = new Conexion();
   
    Connection cn =  mysql.con();        

        try{
    
          pst =cn.prepareStatement(C);
          
          pst.setInt(1, id);
          
          int i = pst.executeUpdate();
          
          if(i != 0){
          return true;    
          }else{
              return false;
          }
            
    }catch(SQLException e){
        JOptionPane.showMessageDialog(null,"Error al elimnar el registro "+e.getMessage());
        
        return false;
    }
            
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaLibros = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        Buscar = new javax.swing.JTextField();
        Edit = new javax.swing.JButton();
        Eliminar = new javax.swing.JButton();
        RECARGAR = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LIBROS");
        jLabel1.setToolTipText("");
        jLabel1.setRequestFocusEnabled(false);

        TablaLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "#", "TITULO", "AUTOR", "GENERO", "AÑO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablaLibros.setAlignmentX(1.0F);
        jScrollPane1.setViewportView(TablaLibros);
        if (TablaLibros.getColumnModel().getColumnCount() > 0) {
            TablaLibros.getColumnModel().getColumn(0).setResizable(false);
            TablaLibros.getColumnModel().getColumn(0).setPreferredWidth(5);
            TablaLibros.getColumnModel().getColumn(4).setResizable(false);
            TablaLibros.getColumnModel().getColumn(4).setPreferredWidth(5);
        }

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("BUSCAR:");

        Buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                BuscarKeyReleased(evt);
            }
        });

        Edit.setText("EDITAR");
        Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditActionPerformed(evt);
            }
        });

        Eliminar.setText("ELIMINAR");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });

        RECARGAR.setText("RECARGAR");
        RECARGAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RECARGARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(RECARGAR, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Edit, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(Eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(RECARGAR, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
        
        boolean Select = false;
        for (int i = 0; i < TablaLibros.getRowCount(); i++) {
            if (Seleccionar(i,5, TablaLibros)) {
                
                Select=true;
                break;
            }
}
            
            if (Select)  {
            int op=JOptionPane.showConfirmDialog(null, "¿Estas seguro de eliminarlo?","Confirmar eliminacion",JOptionPane.YES_NO_CANCEL_OPTION);
                
            if (op == JOptionPane.YES_OPTION) {
                for (int i = 0; i < TablaLibros.getRowCount(); i++) {
                    if (Seleccionar(i,5, TablaLibros)) {
                     eliminar(Integer.parseInt(TablaLibros.getValueAt(i, 0).toString()));
                    
                }
                }
                actualizarTabla();
                JOptionPane.showMessageDialog(null, "Eliminado");
                }else{
                JOptionPane.showMessageDialog(null, "Accion cancelada");
                }
            } else {
        JOptionPane.showMessageDialog(null, "No se han seleccionado libros.");
                }       

        


    }//GEN-LAST:event_EliminarActionPerformed

    private void BuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_BuscarKeyReleased

        BuscarLibroTabla(Buscar.getText());
        
    }//GEN-LAST:event_BuscarKeyReleased

    private void EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditActionPerformed
        
        editar();
        actualizarTabla();
        
    }//GEN-LAST:event_EditActionPerformed

    private void RECARGARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RECARGARActionPerformed

        actualizarTabla();
    }//GEN-LAST:event_RECARGARActionPerformed

public int editar(){
    int c=0;
        int SR = -1; 

        for (int i = 0; i < TablaLibros.getRowCount(); i++) {
            if (Seleccionar(i, 5, TablaLibros)) { 
                c++;
                SR = i; 
            }
        }

        
        if (c == 0) {
            JOptionPane.showMessageDialog(null, "No se han seleccionado libros.");
        } else if (c == 1) {
            
            String titulo, autor, genero,año;
            int id;
            
            id = Integer.parseInt(TablaLibros.getValueAt(SR, 0).toString());
            titulo = TablaLibros.getValueAt(SR, 1).toString();
            autor = TablaLibros.getValueAt(SR, 2).toString();
            genero = TablaLibros.getValueAt(SR, 3).toString();
            año = TablaLibros.getValueAt(SR, 4).toString();
            
            Editar p1 = new Editar();
            p1.ContLibro(id, titulo, autor, genero, año);
            p1.setVisible(true);
            p1.setLocationRelativeTo(Edit);
                        
        } else {
          
            JOptionPane.showMessageDialog(null, "Solo puedes editar un libro");
            
            
            }
         
       return c; 
       
}


public void cambios(){
    
}
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Buscar;
    private javax.swing.JButton Edit;
    private javax.swing.JButton Eliminar;
    private javax.swing.JButton RECARGAR;
    public javax.swing.JTable TablaLibros;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
